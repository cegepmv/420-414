export default function App() {
    function handleClick() {
        console.log("J'ai été cliqué!")
    }


    function handleMouseOver() {
        console.log("On est entré dans l'image.")
    }
    
    return (
        <div className="container">
            <div className="row justify-content-center">
                <img className="img-fluid" src="https://picsum.photos/640/360" onMouseOver={handleMouseOver} />
                <button className="btn btn-primary"  onClick={handleClick}>Bouton</button>
            </div>
        </div>
    )
}