## Event Listeners

### Application dynamique

Jusque là, nous avons fait des pages Web statiques avec React. La principale différence entre un site web statique et une application web est la possibilité pour l'utilisateur d'interagir avec ce qu'il voit à l'écran. 

En Javascript, on utilise des évènements et des "écouteurs d'évènenements" (Event Listeners) pour permettre à l'utilisateur d'interagir avec l'application Web.

Dans une application Javascript "vanille", il y a 2 façons différentes d'ajouter des événements :
1.  Tout d'abord, il y a la méthode `.addEventListener()`. Si vous ajoutez un événement de clic, vous fournirez alors une fonction, et à l'intérieur de cette fonction vous mettrez le code de ce qui doit se passer lorsque l'élément sur lequel vous écoutez un événement est cliqué. 
Voici un exemple :

```html
<button id="btn">
```

```js
const btn = document.getElementById('btn');

function handleClick() {
  console.log("Le bouton a été cliqué");
}

btn.addEventListener("click", handleClick);
```

2. Il existe également une autre façon de procéder qui consiste à mettre `onclick="fonction()"` sur l'élément HTML qu'on veut écouter.

HTML :
```html

<button onclick="fonction()">

```

Script Javascript :
```js
function fonction() {
    // Tâche à faire quand le bouton est cliqué
    console.log("Le bouton a été cliqué");
}
```

Cette deuxième méthode ressemble beaucoup à celle qu'on utilise avec React. Par exemple. Si on veut faire en sorte que lorsque nous cliquons sur un bouton, quelque chose est affiché dans la console, il suffit simplement d'ajouter un `onClick={fonction}` à mon bouton. Contrairement à la méthode précédente, vous remarquerez qu'on utilise un C majuscule :

```jsx
export default function App() {
    function handleClick() {
        console.log("J'ai été cliqué!")
    }
    
    return (
        <div className="container">
            <img src="https://picsum.photos/640/360" />
            <button onClick={handleClick}>Bouton</button>
        </div>
    )
}

```

C'est parce que nous accédons aux propriétés DOM de l'objet qui est créé ici. Pour rappel, React prend l'élément JSX qu'il voit et retourne un objet JavaScript décrivant l'élément DOM qui devrait être "rendu" (rendered) par React. 

Contrairement à la méthode précédente, on n'utilise pas une chaîne de caractères qui a un nom de fonction. On utilise à la place des accolades et on insère une fonction à l'intérieur (notez qu'on ne met pas de parenthèses après le nom de la fonction).

Une autre syntaxe serait d'injecter directement la fonction entre les accolades :

```jsx
export default function App() {

    return (
        <div className="container">
            <img src="https://picsum.photos/640/360" />
            <button 
                onClick={() => console.log("J'ai été cliqué!")}>Bouton</button>
        </div>
    )
}

```
> **Exemple :**
> Complétez le composant `App()` pour que la fonction `handleClick()` s'execute quand on clique sur le bouton.
>```jsx
>export default function App() {
>   
>   function handleClick() {
>       console.log("J'ai été cliqué!")
>   }
>    
>   return (
>       <div className="container">
>           <div className="row">
>               <div className="col">
>                   <img src="https://picsum.photos/640/360" />
>                   <button onClick={}>Bouton</button> 
>               </div>                
>           </div>            
>       </div>
>    )
>}
>```

Pour en savoir plus sur les différents évènements disponibles, voici [un lien qui mène vers la documentation React](https://react.dev/reference/react-dom/components/common#mouseevent-handler) qui décrit les évènemnts disponibles pour la souris (ce qui représente la grande majorité des évènments utilisés dans les applications Web).

### Exercice
Complétez le composant `App()` suivant pour afficher quelque chose sur la console lorsqu'on "survole" l'image avec la souris :

```jsx
export default function App() {
    function handleClick() {
        console.log("J'ai été cliqué!")
    }
    
    
    return (
        <div className="container">
            <img src="https://picsum.photos/640/360" />
            <button onClick={handleClick}>Bouton</button>
        </div>
    )
}
```