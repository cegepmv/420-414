// Ceci est une composante enfant de ComposanteA
function ComposanteA2() {
    return (
        <p>Ceci est la Composante A2</p>
    );
}

export default ComposanteA2;