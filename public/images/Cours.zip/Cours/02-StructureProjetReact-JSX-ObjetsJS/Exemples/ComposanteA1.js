// Ceci est une composante enfant de ComposanteA
function ComposanteA1() {
    return (
        <p>Ceci est la Composante A1</p>
    );
}

export default ComposanteA1;