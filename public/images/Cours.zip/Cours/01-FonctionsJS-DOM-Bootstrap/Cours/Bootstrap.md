# Bootstrap
*Bootstrap* est un ensemble prédéfini de classes CSS qui facilite l’organisation des éléments d’une page. Avec *Bootstrap*, on peut créer facilement les composantes habituelles d’une page web moderne (boutons, menus, caroussels d’images, etc.), modifier les éléments typographiques (titres, couleurs, listes et citations) et surtout réorganiser dynamiquement les éléments d’une page selon la taille de l’écran.

Pour utiliser *Bootstrap* dans un document HTML, il faut lui ajouter les références suivantes dans l’entête (la balise <head>):

```html
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
```
## Structure
La structure d’une page en *Bootstrap* comprend trois niveaux:

* Conteneurs
* Rangées
* Colonnes

Les conteneurs contiennent les rangées et les rangées contiennent les colonnes. Ces composantes correspondent à des classes CSS qu’on donne à des éléments `<div>` dans le DOM. Par exemple, pour le code HTML suivant:

```html
<div class="container">
    <div class="row">
        <div class="col"></div>
        <div class="col"></div>
    </div>
    <div class="row">
        <div class="col"></div>
        <div class="col"></div>
        <div class="col"></div>
    </div>
    <div class="row">
        <div class="col"></div>
    </div>
</div>
```

on aura la disposition suivante:

struct

### `container`
C’est l’élément de base. Identifié par `<div class="container">`.

* La classe `container` a une marge et une largeur inférieure à celle de l’écran
* La classe `container-fluid` occupe la pleine largeur de l’écran.
En général, on utilise un seul conteneur par page.

### `row`
Les rangées permettent de diviser l’espace d’un conteneur du haut en bas. Elles sont identifiées par `<div class="row">`. On peut en mettre autant qu’on veut dans un même conteneur.

La taille verticale d’une rangée est déterminée par son contenu.

### `column`
Les colonnes divisent de gauche à droite l’espace d’une rangée. Elles sont identifiées par `<div class="col">`.

La taille horizontale d’une colonne est déterminée par le nombre total de colonnes de la rangée: donc si une rangée contient 2 colonnes, chacune occupe la moitié de l’espace; si elle en contient 3, chacune occupe un tiers de l’espace; etc.

Il est cependant possible de spécifier des proportions différentes.

### La grille bootstrap
Le modèle de *bootstrap* est basé sur une grille de 12 colonnes: si on veut contrôler nous-mêmes la taille des colonnes il faut ajouter un suffixe numérique d’une valeur de 1 à 12 à la classe **col**. Ce nombre correspond à la largeur (sur 12) que la colonne occupe dans la page. Par exemple:

* col-1 a une largeur de 1/12 de la page
* col-4 a une largeur de 4/12 (donc un tiers) de la page
* col-9 a une largeur de 3/4 de la page
* etc.

Lorsqu’on ne spécifie pas de taille, toute la largeur est occupée; ainsi col-12 a le même effet que col.

Donc, pour la structure suivante:
```html
<div class="container">
    <div class="row">
        <div class="col-8"></div>
        <div class="col-4"></div>
    </div>
    <div class="row">
        <div class="col-3"></div>
        <div class="col-6"></div>
        <div class="col-3"></div>
    </div>
</div>    
```html

on aura la disposition suivante:

grille

(exemple)

Transitions
Afin de permettre au contenu d’une page de bien s’adapter aux différentes tailles des écrans (PC, tablette, cellulaire…), bootstrap définit 6 tailles d’écran possibles:

xs: extra-small
sm: small
md: medium
lg: large
xl: extra-large
xxl: extra-extra-large
Lorsque l’écran est redimensionné, on peut utiliser ces tailles avec les classes col pour ajuster la taille des colonnes. Par exemple class="col-md-6" signifie qu’on a une largeur de 6 pour les tailles medium et plus; les tailles inférieures, puisqu’elles ne sont pas spécifiées, occupent la pleine largeur.

Dans l’exemple suivant, 3 div ont la classe col-sm-4; donc, chaque div occupe un tiers (4/12) de l’espace pour la taille d’écran “small” et les tailles plus grandes:

<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <h2>col-sm-4</h2>
            <p>Cras porttitor ullamcorper diam et vulputate. Praesent non mauris nec sem consequat auctor nec vel leo. Aenean pulvinar enim ac iaculis convallis.</p>
        </div>
        <div class="col-sm-4">
            <h2>col-sm-4</h2>
            <p>Cras porttitor ullamcorper diam et vulputate. Praesent non mauris nec sem consequat auctor nec vel leo. Aenean pulvinar enim ac iaculis convallis.</p>
        </div>
        <div class="col-sm-4">
            <h2>col-sm-4</h2>
            <p>Cras porttitor ullamcorper dam et vulputate. Praesent non mauris nec sem consequat auctor nec vel leo. Aenean pulvinar enim ac iaculis convallis.</p>
        </div>
    </div>
</div>    
(exemple)

Puisque xs est la taille minimale, il n’y a pas de transition entre elle et une taille plus petite. Il est donc inutile de définir une largeur de colonne comme col-xs-3, puisque cela est équivalent à col-3.
On peut définir plus d’une transition pour un même élément. Par exemple une rangée peut contenir 4 éléments pour les grandes tailles, 2 rangées de 2 éléments pour les tailles moyennes et 4 rangées de 1 élément pour les petites tailles. Pour ce fait il suffit de donner deux classes pour un même élément. L’exemple suivant illustre ceci:

<div class="container">
    <div class="row">
        <div class="col-sm-6 col-lg-3">
            <h2>Titre 1</h2>
            <p>Cras porttitor ullamcorper diam et vulputate. Praesent non mauris nec sem consequat auctor nec vel leo. Aenean pulvinar enim ac iaculis convallis.</p>
        </div>
        <div class="col-sm-6 col-lg-3">
            <h2>Titre 2</h2>
            <p>Cras porttitor ullamcorper diam et vulputate. Praesent non mauris nec sem consequat auctor nec vel leo. Aenean pulvinar enim ac iaculis convallis.</p>
        </div>
        <div class="col-sm-6 col-lg-3">
            <h2>Titre 3</h2>
            <p>Cras porttitor ullamcorper diam et vulputate. Praesent non mauris nec sem consequat auctor nec vel leo. Aenean pulvinar enim ac iaculis convallis.</p>
        </div>
        <div class="col-sm-6 col-lg-3">
            <h2>Titre 4</h2>
            <p>Cras porttitor ullamcorper diam et vulputate. Praesent non mauris nec sem consequat auctor nec vel leo. Aenean pulvinar enim ac iaculis convallis.</p>
        </div>
    </div>
</div>    
(exemple)

Composantes
Dans cette section nous allons voir quelques exemples des composantes et éléments de style offerts par Bootstrap. La liste est très courte; l’objectif ici est simplement de se faire une idée générale de la manière dont on peut utiliser les éléments de style de ce cadriciel. Au fil de la session, nous aurons l’occasion de voir d’autres éléments.

Pour plus de détails sur les composantes Bootstrap, vous pouvez vous référer à la documentation technique (https://getbootstrap.com/docs/5.0/getting-started/introduction/)

Images
Classe: img-fluid
Élément: <img>
Lorsqu’on l’ajoute à un élément <img>, la classe img-fluid a pour effet de redimensionner automatiquement l’image afin qu’elle soit toujours de la taille de l’élément qui la contient.

<img class="img-fluid" src="test.png" />
Boutons
Classe principale: btn
Classes de style: btn-lg, btn-sm, btn-primary, btn-secondary, etc.
Éléments: <button>, <a>
<button type="button" class="btn btn-primary">Bouton "button"</button>
<a type="button" class="btn btn-primary" href="#">Bouton "a"</a>
Tous les boutons doivent avoir la classe btn; ensuite, selon le style qu’on veut leur donner on peut attribuer des classes pour leur taille (btn-lg, btn-sm) ou pour leur couleur (btn-primary, btn-secondary).

La classe active accentue la couleur du bouton.

La classe disabled désactive le bouton. Ceci a pour effet d’atténuer sa couleur et de rendre le clic impossible.

Menu
Classes: nav, nav-item, nav-link
Éléments: <ul>, <li>
<ul class="nav">
    <li class="nav-item">
        <a class="nav-link" href="#">Item 1</a> 
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Item 2</a> 
    </li>
</ul>
L’élément parent d’un menu est <ul> et on doit lui donner la classe nav; chaque item du menu correspond à un sous-élément <li> qui doit avoir la classe nav-item et le lien <a> vers la page de destination doit avoir la classe nav-link.

Comme pour les boutons, la classe active accentue la couleur de l’item du menu, et la classe disabled désactive l’item du menu.

Ces classes permettent de créer des menus simples. La classe navbar, plus flexible mais plus complexe, donne accès à des fonctionnalités de menu plus élaborées.
Cards
Classes principales: card, card-body, card-title, card-text
Classes secondaires: card-header, card-footer, card-img-top, etc.
Les “cartes” sont un type de conteneur simple qui permet de regrouper dans un petit espace des informations de toutes sortes. Elles ont une bordure par défaut et peuvent contenir des images, des titres, du texte, des boutons, etc.

Le format minimal de carte (qui contient uniquement du texte) contient deux <div> imbriqués; le parent a la classe card et l’enfant a la classe card-body:

<div class="card">
    <div class="card-body">
        <p>Texte de la carte</p>
    </div>
</div>
Pour ajouter une image à la carte, on utilise un élément <img>. Celui-ci doit avoir card comme parent immédiat.

Le code suivant montre un exemple de carte plus complexe qui comprend une entête et un pied, une image, un titre et du contenu texte:

<div class="card">
    <div class="card-header p-3">
        Entête
    </div>
    <img src="patate.png" />
    <div class="card-body text-center">
        <h5 class="card-title">Titre de la carte</h5>
        <p class="card-text">Texte de la carte</p>
    </div>
    <div class="card-footer">
        Pied
    </div>
</div>