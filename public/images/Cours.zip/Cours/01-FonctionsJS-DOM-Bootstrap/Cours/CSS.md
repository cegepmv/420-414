# CSS

Il est possible de modifier l’apparence des éléments d’une page directement dans le code HTML en utilisant les attributs de style. Par exemple, pour changer la couleur du texte d’un paragraphe:

```html
<div>
    <p>Texte normal</p>
    <p style="color:red">Texte rouge</p>
    <p style="background-color:yellow">Arrière-plan jaune</p>
</div>
```

On recommande cependant de regrouper ces propriétés dans un fichier CSS: ceci permet de centraliser les éléments de style et de permettre plus facilement les modifications. Par exemple, si on souhaite que les citations dans un texte soient en italique, sans serif et de couleur grise, on pourra définir une classe nommée “citation” dans un fichier CSS et y spécifier ces propriétés typographiques, comme suit:

```css
.citation {
    font-family: sans-serif;
    color: grey;
    font-style: italic;
}
```

Par la suite, on attribue la classe `citation` à l’élément HTML dont on veut modifier le style:

```html
<p class="citation">Alea Jacta Est</p>
```

Pour que le navigateur puisse retrouver le fichier CSS où le style est défini, il faut y ajouter une référence dans le fichier HTML dans un élément `<link>`. En supposant que le fichier qui contient les styles se nomme styles.css, on aura donc le code HTML suivant:

```html
<!DOCTYPE html>
<html>
    <head>
        <link href="styles.css" rel="stylesheet">
    </head>
    <body>
        <p class="citation">Alea Jacta Est</p>
        <p>- Jules César</p>
    </body>
</html>
```
Fichier HTML source :
```html
<!DOCTYPE html>
<html>
    <head>
        <link href="styles-intro.css" rel="stylesheet">
    </head>
    <body>
        <p class="citation">Alea Jacta Est</p>
        <p>- Jules César</p>
    </body>
</html>
```

Fichier CSS source :
```css
.citation {
    font-family: sans-serif;
    color: grey;
    font-style: italic;
}
```

Une référence complète des propriétés CSS est disponible sur le site de [W3 Schools](https://www.w3schools.com/cssref/index.php).