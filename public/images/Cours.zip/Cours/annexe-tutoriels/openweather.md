# Utiliser l'API Open Weather

Open Weather est une API gratuite qui permet (entre autre) de recevoir la météo courante pour une ville donnée. Certaines fonctionnalité requièrent un abonnement payant, mais pour l'objet du cours, la version gratuite sera amplement suffisante.

## Utilisation

1. Créez un compte sur le [site de Open Weather](https://openweathermap.org/)
2. Après avoir crée un compte, récupérez votre clé API :

![02.png](02.png)

![02.1.png](02.1.png)

3. Ensuite, créez un composant et faites un appel à l'URL suivant: `https://api.openweathermap.org/data/2.5/weather?q=<VILLE>&units=metric&appid=<CLÉ API>` en utilisant `fetch()`, `useEffect()` et un *state* (`useState()`) pour stocker les données. Cet URL contient 2 choses que vous devez remplir:
* VILLE: la ville dont vous souhaitez connaître la météo
* CLÉ API: la clé API que vous avez récupéré aux étapes précédentes.

Votre code devrait ressembler à celui-ci :

```jsx
import React from "react"

export default function App() {
    const [weatherData, setWeatherData] = React.useState(null)
    const APIKEY = "<VOTRE CLÉ API>"
    const city = "Montréal"

    React.useEffect(() => {
        fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${APIKEY}`)
            .then(response => response.json())
            .then(data => setWeatherData(data))
    }, [])

    return (
        <div className="container">
            <div className="row">
                <pre>{JSON.stringify(weatherData, null, 2)}</pre>
            </div>
        </div>
    )
}
```