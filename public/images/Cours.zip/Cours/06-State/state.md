# useState

## L’état des composants
Lorsqu’on évoque l’état d’un composant, on parle des variables qu’il contient, plus précisément des valeurs de ces variables et de leur changements lorsque l’application s’exécute. L’état d’un composant est donc la valeur de ses variables à un moment donné durant son exécution. Pour qu’un composant puisse “avoir” des variables et changer leurs valeurs, il doit pouvoir les garder en mémoire.


En programmation, lorsqu’on souhaite que certains éléments d’un programme “mémorisent” des informations, on crée des classes et des objets, et on met dans leurs propriétés les informations qu’on veut mémoriser. Mais en React, le composants ne sont pas des objets: ils sont définis dans des fonctions. Donc, on ne peut pas utiliser des propriétés pour faire en sorte que les composantes gardent des informations en mémoire.


La fonction `useState` est la solution à ce problème. Comme nous le verrons plus loin, c’est cette foction qui est utilisée dans la gestion des évènements en React.


Cette fonction tire parti du fait qu’en javascript il est possible de traiter les fonctions comme n’importe quelle variable; c’est-à-dire qu’une fonction peut, comme une variable, être passée en paramètre à une autre fonction ou encore être retournée par une autre fonction.

## Des fonctions qui retournent d’autres fonctions
Nous avons vu précédemment comment des fonctions peuvent être passées comme paramètre à d’autres fonctions avec `filter()` et `map()`. Dans ce qui suit nous verrons quelle est l’utilité d’avoir une fonction comme valeur de retour.

Prenons tout d’abord le code suivant:

```jsx
function exposant(exp) {
    return function(n) {
        return n ** exp;
    };
}

function App() {
    const carre = exposant(2);
    const cube = exposant(3);
    
    return (
        <div>
            <p>{carre(3)}</p>
            <p>{cube(2)}</p>
        </div>
    );
}

export default App;
```

Dans cet exemple, la fonction `exposant()` sert à générer une fonction anonyme. Cette fonction anonyme prend un nombre comme paramètre et calcule la puissance de ce nombre; mais au moment de sa définition, on ne sait pas quel est cet exposant. Donc si on a besoin d’une fonction qui calcule la puissance 2, on appelle `exposant()` avec 2 comme paramètre et elle nous retourne une fonction qui calcule la puissance 2 d’un nombre; si on a besoin d’une fonction qui calcule la puissance 3, on passe la valeur 3 à `exposant()` et elle nous retourne la fonction correspondante; etc.

Un autre exemple, où la fonction `convertirVers()` retourne une fonction de conversion de Celsius à Fahrenheit ou l’inverse:

```jsx
function convertirVers(unite) {
    if (unite === 'F') {
        return function(degres) {
        return degres * 9/5 + 32; 
        }
    } else if (unite === 'C') {
        return function(degres) {
        return (degres - 32) * 5/9; 
        }
    } 
}

function App() {

    const CtoF = convertirVers('F');
    const FtoC = convertirVers('C');

    return (
        <div>
            <p>100 degrés C = {CtoF(100)} degrés F</p>
            <p>100 degrés F = {FtoC(100)} degrés C</p>
        </div>
    );
}

export default App;
```

## useState()
Dans les exemples précédents, on utilise des fonctions pour “construire” d’autres fonctions, mais il y a d’autres manières d’utiliser le fait qu’une fonction puisse être retournée par une autre.

Prenons le code suivant, où un bouton sert à incrémenter une valeur affichée dans la page:

```jsx
function App() {

    let compteur = 0;

    function incrementer() {
        let elem = document.getElementById("elem");
        compteur++;
        elem.textContent = compteur;
    }

    return (
        <div>
            <div id="elem">0</div>
            <button onClick={incrementer}>Clic</button>
        </div>
    );
}
```

Même si le programme fonctionne et donne les résultats attendus, son architeture n’est pas idéale. Il est possible par exemple qu’on veuille modifier la valeur autrement qu’en utilisant un évènement; cependant, dans ce code la valeur de l’élément et l’évènement sont fortement reliés. Ensuite, si on veut modifier la valeur affichée dans `<div id="elem">0</div>` autrement qu’en cliquant sur le bouton ou en l’incrémentant, il faudra définir une novelle fonction. Cet exemple est simple, mais dans des pages plus complexes où les valeurs affichées dans les composantes peuvent être plus nombreuses et peuvent changer selon différents facteurs, savoir ce qui est à l’origine d’une valeur qui change peut devenir très difficile.

La solution à ce problème est d’utiliser toujours la même fonction (la fonction `useState`) pour gérer les changements de valeur dans les composantes. Dans le code qui suit, on refactorise le programme de l’exemple précédent avec `useState`:

```jsx
import React, { useState } from 'react';

function App() {
  const [compteur, modifCompteur] = useState(0);

  function incrementer() {
    modifCompteur(compteur + 1);
  };

  return (
    <div>
        <div id="elem">{compteur}</div>
        <button onClick={incrementer}>Clic</button>
    </div>
  );
}

export default App;
```

La fonction `useState` est utilisée lorsqu’on veut stocker une variable associée à un composant et avoir la possibilité de la modifier par la suite. Elle prend un seul paramètre qui correspond à la valeur initiale qu’on veut donner à cette variable. Elle retourne une liste qui comprend deux éléments:

* La variable en question
* Une fonction qui sert à changer la valeur de cette variable


Dans l’exemple précédent, on veut que le compteur soit initialisé à 0: donc on appelle `useState(0)`. Cette fonction retourne une liste:

* On donne le nom `compteur` au premier élément de cette liste car c’est la variable qui contient la valeur qu’on veut incrémenter.
* On donne le nom `modifCompteur` au deuxième élément de cette liste car c’est la fonction qui sert à modifier la valeur de compteur.
* On définit ensuite la fonction `incrementer()` qui appelle `modifCompteur` et lui passe la valeur `compteur + 1`. C’est cette fonction incrementer qu’on lie ensuite à l’évènement `onClick` de l’élément `<button>`.

>Pour utiliser `useState`, il faut l’importer dans notre programme en y ajoutant la ligne suivante:

>```jsx
> import React, { useState } from 'react';
>```

## Deuxième exemple: passer un booléen
Dans l’exemple suivant, on utilise `useState` avec une variable booléenne pour ajouter une classe CSS à un élément `<div>`, ce qui a pour effet de le rendre invisible:

```jsx
import React, { useState } from 'react';
import './styles.css';

function App() {
  const [estVisible, changer] = useState(true);

  const handleButton= () => {
    changer(!estVisible);
  };

  return (
    <div>
        <button onClick={handleButton}>Changer Visibilité</button>
        <div className={!estVisible ? 'invisible' : ''}>
            <h1>Un titre</h1>
            <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque congue est ut augue maximus finibus. Proin faucibus scelerisque purus at tempor. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed bibendum tristique viverra. Fusce eu elit bibendum, congue dui vel, condimentum orci. Sed nisi leo, laoreet eu feugiat non, vehicula sed ipsum. Curabitur euismod vulputate massa et volutpat. 
            </p>
        </div>
    </div>
  );
}

export default App;
```

Pour que l’exemple précédent fonctionne, votre fichier styles.css doit contenir la classe suivante:

```css
.invisible {
    visibility: hidden;
}
```

## Troisième exemple: passer un objet
Dans ce dernier exemple, c’est un objet entier, avec toutes les propriétés qu’il contient, qu’on passe à `useState`:

```jsx
import React, { useState } from 'react';

const film1 = {
    titre: "Parasite",
    real: "Bong Joon-ho",
    annee: 2019,
    acteurs: ['Cho Yeo jeong', 'Song Kang-ho', 'Choi Woo-ship']
}

const film2 = {
    titre: "The Square",
    real: "Ruben Ostlund",
    annee: 2017,
    acteurs: ['Claes Bang', 'Elisabeth Moss', 'Dominic West']
}

function App() {
  const [filmSelectionne, changerFilm] = useState(film1);

  const handleButton1= () => {
    changerFilm(film1);
  };

  const handleButton2= () => {
    changerFilm(film2);
  };

  return (
    <div>
        
        <div>
            <h3>{filmSelectionne.titre}</h3>
            <h4>{filmSelectionne.annee}</h4>
            <h4>Réalisation: {filmSelectionne.real}</h4>
            <ul>
                {filmSelectionne.acteurs.map( (e) => <li>{e}</li>)}
            </ul>
        </div>
        <button onClick={handleButton1}>Film 1</button>
        <button onClick={handleButton2}>Film 2</button>
    </div>
  );
}

export default App;
```